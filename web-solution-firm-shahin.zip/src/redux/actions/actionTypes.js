// All types of actions 
export const ACTIVEMENU='ACTIVEMENU';
export const SOLUTION_ACTIVE_MENU='SOLUTION_ACTIVE_MENU';

