import React from 'react';
import logo from '../../src/logo.svg';
import { BiSearch } from 'react-icons/bi';
import Solutions from './../solutions/Solutions';
import Industries from './../industries/Industries';
import { Route, Routes, useNavigate } from 'react-router-dom';
import { useDispatch, useSelector } from 'react-redux';


const Home = () => {
    const activeMenu = useSelector(state => state.activeMenuReducer)
    const navigate = useNavigate();
    return (
        <>
            <div className="nav-section">
                <header className='c-navbar'>
                    <a  className='logo'><img src={logo} alt="" /></a>
                    <nav className='c-nav'>
                        <div onClick={() => (navigate('solutions'))}>
                            <a>Solution</a>
                            {activeMenu.solution?
                            <span  style={{ display: 'block' }}></span>
                            :''}
                        </div>
                        <div onClick={() => (navigate('industries'))}>
                            <a >Industry</a>
                            {activeMenu.industry?
                            <span  style={{ display: 'block' }}></span>
                            :''}
                        </div>
                        <div><a href="">Discover</a></div>
                        <div><a href="">About Us</a></div>
                        <div><a href="">Careers</a></div>
                    </nav>
                    <div className='sign-in-search'>
                        <a href=""><span>Sign in</span></a>
                        <div className='search'><BiSearch /></div>
                    </div>
                    <Routes>
                        <Route path='solutions/*' element={<Solutions />} />
                        <Route path='industries' element={<Industries />} />
                    </Routes>

                </header>
            </div>
        </>
    );
};

export default Home;