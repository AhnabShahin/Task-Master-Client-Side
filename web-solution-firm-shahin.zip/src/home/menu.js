export const menu = {
    solution: false,
    industry: false,
    discover: false,
    aboutUs: false,
    careers: false,
}
export const solutionMenu = {
    advisoryAndConsulting: false,
    cloudServicess: false,
    contactCentres: false,
}
